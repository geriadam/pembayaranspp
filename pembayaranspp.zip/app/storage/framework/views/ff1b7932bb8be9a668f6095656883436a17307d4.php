<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Pembayaran SPP</title>
    <?php echo $__env->make("includes.head", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="gray-bg">
    <div class="middle-box text-center loginscreen animated fadeInDown">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>