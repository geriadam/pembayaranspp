<html>
<head>
    <title>Print Transaksi - <?php echo e(\Carbon\Carbon::parse(date('d-m-Y'))->format('d M Y')); ?></title>
    <style type="text/css">
        body, html { height: 100%; padding: 0; margin: 0;  }
        .hr { width: 100%;border-style: dashed;border-top-width: 0.5px;border-bottom-width: 0.5px;margin-top: 5px;margin-bottom: 25px }
        #table-santri-detail td, #table-detail-transaksi td, #table-item-transaksi td, #table-item-transaksi th { font-size: 9pt; }

        #table-santri-detail .title-detail-santri { width: 30%; }
        #table-detail-transaksi { margin-bottom: 20px; margin-top: 20px }
        #detail-profile h2 { margin-bottom: 0 }
        #detail-profile h6 { margin-bottom: 0 }
    </style>
</head>
<body>
    <table border="0" width="100%" id="detail-profile">
        <tr>
            <td width="70%" align="center"><h2><?php echo e($profile->pesantren_profile_name); ?></h2></td>
            <td rowspan="2" align="center">
                <?php if(!empty($profile->pesantren_profile_logo) 
                    && file_exists(App\PesantrenProfile::IMAGE_PATH.$profile->pesantren_profile_logo)): ?>
                  <img src="<?php echo e(url(App\PesantrenProfile::IMAGE_PATH.$profile->pesantren_profile_logo)); ?>" width="50" height="50">
                <?php endif; ?>
            </td>
        </tr>
        <tr align="center">
            <td><h6><?php echo e($profile->pesantren_profile_address); ?></h6></td>
        </tr>
    </table>
    <div class="hr"></div> 
    <center>
        <table align="center" id="table-detail-transaksi">
            <tr>
                <td width="10%">No. Transaksi</td>
                <td>:</td>
                <td>#<?php echo e($model->transaction_number); ?></td>
            </tr>
            <tr>
                <td width="10%">Operator</td>
                <td>:</td>
                <td><?php echo e(\Session::get('name')); ?></td>
            </tr>
            <tr>
                <td width="10%">Waktu</td>
                <td>:</td>
                <td><?php echo e(\Carbon\Carbon::parse(date('d-m-y H:i:s'))->format("d/m/Y H:i:s")); ?></td>
            </tr>
        </table>
    </center>
    <table width="100%" id="table-santri-detail">
        <tr>
            <td class="title-detail-santri">Nama Santri</td>
            <td width="5%">:</td>
            <td><?php echo e($model->santri->santri_name); ?></td>
        </tr>
        <tr>
            <td class="title-detail-santri">Tempat, Tanggal lahir</td>
            <td width="5%">:</td>
            <td><?php echo e($model->santri->santri_birth_place); ?>, <?php echo e(\Carbon\Carbon::parse($model->santri->santri_birth_date)->format("d M Y")); ?></td>
        </tr>
        <tr>
            <td class="title-detail-santri">Jenis Kelamin</td>
            <td width="5%">:</td>
            <td><?php echo e($model->santri->santri_gender); ?></td>
        </tr>
        <tr>
            <td class="title-detail-santri">Alamat</td>
            <td width="5%">:</td>
            <td><?php echo e($model->santri->santri_address); ?></td>
        </tr>
    </table>
    <br><br>
    <table border="0" width="100%" id="table-item-transaksi">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="25%">Jenis Pembayaran</th>
                <th width="20%">Bulan</th> 
                <th width="20%">Rupiah</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $modelItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $transactionitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($transactionitem->paymenttype->payment_type_name); ?></td>
                    <td>
                        <?php if($transactionitem->transaction_month != 0): ?>
                            <?php echo e($month[$transactionitem->transaction_month]); ?>-<?php echo e($transactionitem->transaction_year); ?>

                        <?php else: ?>
                            <?php echo e("-"); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e(NumberHelper::format_uang($transactionitem->transaction_price)); ?></td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2"></td>
                <td>Total</td>
                <td><b><?php echo e(NumberHelper::format_uang($model->transaction_total)); ?></b></td>
            </tr>
        </tfoot>
    </table>
</body>
</html> 