<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <em>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </em>
  </div>
<?php endif; ?>
<div class="row">
  <div class="col-lg-12">
    <?php echo e(Form::open(['route' => 'admin.pesantrenprofile.store', 'files' => TRUE])); ?>

    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <a class="collapse-link">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>
      </div>
      <div class="ibox-content">
        <div class="form-group">
            <strong>Name:</strong>
            <?php echo Form::text('pesantren_profile_name', null, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Address:</strong>
            <?php echo Form::textarea('pesantren_profile_address', null, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Logo:</strong>
            <?php echo Form::file('file', null, ["class" => "form-control"]); ?>

        </div>
      </div>
      <div class="ibox-content">
        <button type="submit" class="btn btn-primary">Save</button>
        <button type="reset" class="btn btn-danger btn-large">Reset</button>
      </div>
    </div>
    <?php echo Form::close(); ?>  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>