<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-content">
                <?php if(count($model) == 0): ?>
                    <a href="<?php echo e(route('admin.pesantrenprofile.create')); ?>">
                        <button type="button" class="btn btn-primary btn-raised"> Create</button>
                    </a>
                <?php else: ?>
                    <a href="#">
                        <button type="button" class="btn btn-primary btn-raised disabled"> Create</button>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-content">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover dataTable" id="index-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Logo</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pesantrenprofile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($pesantrenprofile->pesantren_profile_name); ?></td>
                                    <td><?php echo e($pesantrenprofile->pesantren_profile_address); ?></td>
                                    <td>
                                        <?php if(!empty($pesantrenprofile->pesantren_profile_logo) 
                                            && file_exists(App\PesantrenProfile::IMAGE_PATH.$pesantrenprofile->pesantren_profile_logo)): ?>
                                          <br>
                                          <img src="<?php echo e(url(App\PesantrenProfile::IMAGE_PATH.$pesantrenprofile->pesantren_profile_logo)); ?>" width="100px" height="100px">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.pesantrenprofile.edit', ['id' => $pesantrenprofile->pesantren_profile_id])); ?>">
                                            <span class="btn btn-warning dim btn-sm glyphicon glyphicon-pencil"></span>
                                        </a>
                                        <a href="<?php echo e(route('admin.pesantrenprofile.destroy', ['id' => $pesantrenprofile->pesantren_profile_id])); ?>" class="btn disabled" id="delete-btn">
                                            <span class="btn btn-danger dim btn-sm glyphicon glyphicon-remove-sign"></span>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 
<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>