<nav class="navbar-default navbar-static-side" role="navigation">
  <div class="sidebar-collapse">
    <ul class="nav metismenu" id="side-menu">
      <li class="nav-header">
        <div class="dropdown profile-element"> 
          <a data-toggle="dropdown" class="dropdown-toggle" href="#">
            <span class="clear"> 
              <span class="block m-t-xs"> <strong class="font-bold"><?php echo e(\Session::get('name')); ?></strong></span>
            </span>
          </a>
        </div>
        <div class="logo-element">
          Hakiki
        </div>
      </li>
      <?php $__currentLoopData = MenuHelper::getArrOfMenu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($menu['visible']): ?>
          <li class="<?php echo e(isset($menu['active']) && $menu['active'] ? 'active' : ''); ?>">
            <a href="<?php echo e($menu['url'] != '#' ? route($menu['url']) : '#'); ?>">
              <i class="fa fa-<?php echo e($menu['icon']); ?>"></i> <span class="nav-label"><?php echo e($menu['label']); ?></span>
              <?php if(isset($menu['items']) && !empty($menu['items'])): ?>
                <span class="fa arrow"></span>
              <?php endif; ?>
            </a>
            <?php if(isset($menu['items']) && !empty($menu['items'])): ?>
              <ul class="nav nav-second-level collapse">
                <?php $__currentLoopData = $menu['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($secondMenu['visible']): ?>
                    <li class="<?php echo e(isset($secondMenu['active']) && $secondMenu['active'] ? "active" : ""); ?>">
                      <a href="<?php echo e($secondMenu['url'] != '#' ? route($secondMenu['url']) : '#'); ?>">
                        <?php echo e($secondMenu['label']); ?>

                        <?php if(isset($secondMenu['items']) && !empty($secondMenu['items'])): ?>:?>
                          <span class="fa arrow"></span>
                        <?php endif; ?>
                      </a>
                      <?php if(isset($secondMenu['items']) && !empty($secondMenu['items'])): ?>
                        <ul class="nav nav-third-level">
                          <?php $__currentLoopData = $secondMenu['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thirdMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($thirdMenu['visible']): ?>
                              <li class="<?php echo e(Request::is($thirdMenu['url']) ? 'active' : ''); ?>">
                                <a href="<?php echo e(route($thirdMenu['url'])); ?>">
                                  <?php echo e($thirdMenu['label']); ?>

                                </a>
                              </li>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      <?php endif; ?>
                    </li>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>
          </li>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</nav>