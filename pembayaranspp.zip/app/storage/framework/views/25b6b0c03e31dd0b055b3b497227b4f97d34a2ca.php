<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-title">
                Filter
            </div>
            <?php echo e(Form::open(['route' => 'admin.report.search', 'method' => 'GET'])); ?>

            <div class="ibox-content">
                <div class="form-group">
                    <strong>Nama Santri:</strong>
                    <?php echo Form::select('santri_id', $santri ,null , ["class" => "form-control select2-select"]); ?>

                </div>
                <div class="form-group">
                    <strong>No Transaksi:</strong>
                    <?php echo Form::text('transaction_number', null, ["class" => "form-control"]); ?>

                </div>
                <div class="col-md-12 row">
                    <div class="col-md-6" style="padding-left: 0; margin-bottom: 2%">
                        <strong>Dari Tanggal</strong>
                        <?php echo Form::text('start_date', null, ["class" => "form-control datepicker"]); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Ke Tanggal</strong>
                        <?php echo Form::text('end_date', null, ["class" => "form-control datepicker"]); ?>

                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" value="true" name="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-title">
                <a href="<?php echo e(route('admin.report.export')); ?>" target="_blank">
                    <button type="button" class="btn btn-primary">Export</button>
                </a>
            </div>
            <div class="ibox-content">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover dataTable" id="index-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th width="20%">Nama Santri</th>
                                <th width="15%">No Transaksi</th>
                                <th width="20%">Tanggal Transaksi</th>
                                <th width="30%">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($transaction->santri->santri_name); ?></td>
                                    <td><?php echo e($transaction->transaction_number); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($transaction->transaction_date)->format('d M Y')); ?></td>
                                    <td><?php echo e(NumberHelper::format_uang($transaction->transaction_total)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 
<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>