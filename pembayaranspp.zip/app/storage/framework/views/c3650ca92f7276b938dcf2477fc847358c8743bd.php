<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <em>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </em>
  </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-12">
        <div class="ibox">
            <div class="ibox-content">
                <a href="<?php echo e(route('admin.santri.index')); ?>">
                    <button type="button" class="btn btn-info btn-raised"><span class="glyphicon glyphicon-triangle-left"></span> 
                      Back
                    </button>
                </a>
            </div>
        </div>
    </div>
</div>
<div class="row">
  <div class="col-lg-12">
    <?php echo e(Form::open(['route' => ['admin.santri.update', $santri->santri_id], 'method' => "PUT", "files" => TRUE])); ?>

    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <a class="collapse-link">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>
      </div>
      <div class="ibox-content">
        <div class="form-group">
            <strong>Nomor Santri:</strong>
            <?php echo Form::text('santri_number', $santri->santri_number, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Nama Santri:</strong>
            <?php echo Form::text('santri_name', $santri->santri_name, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Nama Panggilan:</strong>
            <?php echo Form::text('santri_nick_name', $santri->santri_nick_name, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
          <strong>Tempat, Tanggal lahir:</strong>
        </div>
        <div class="form-group col-md-4">
            <?php echo Form::text('santri_birth_place', $santri->santri_birth_place, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group col-md-8">
          <?php echo Form::text('santri_birth_date', $santri->santri_birth_date, ["class" => "form-control datepicker"]); ?>

        </div>
        <div class="form-group">
            <strong>Jenis Kelamin:</strong>
            <?php echo Form::select('santri_gender', $gender ,$santri->santri_gender , ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Anak Ke - :</strong>
            <?php echo Form::text('santri_order_child', $santri->santri_order_child , ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Alamat</strong>
            <?php echo Form::textarea('santri_address', $santri->santri_address, ["class" => "form-control meta-desc"]); ?>

        </div>
      </div>
    </div>

    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <a class="collapse-link">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>
      </div>
      <div class="ibox-content">
        <div class="form-group">
            <strong>Nama Sekolah</strong>
            <?php echo Form::text('santri_school', $santri->santri_school , ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Alamat Sekolah</strong>
            <?php echo Form::textarea('santri_school_address', $santri->santri_school_address, ["class" => "form-control meta-desc"]); ?>

        </div>
      </div>
    </div>

    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <a class="collapse-link">
            <i class="fa fa-chevron-up"></i>
          </a>
        </div>
      </div>
      <div class="ibox-content">
        <div class="form-group">
            <strong>Nama Orang Tua</strong>
            <?php echo Form::text('santri_parent_name', $santri->santri_parent_name , ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Alamat Orang Tua</strong>
            <?php echo Form::textarea('santri_parent_address', $santri->santri_parent_address, ["class" => "form-control meta-desc"]); ?>

        </div>
        <div class="form-group">
            <strong>Pekerjaan Orang Tua</strong>
            <?php echo Form::text('santri_parent_job', $santri->santri_parent_job, ["class" => "form-control"]); ?>

        </div>
        <div class="form-group">
            <strong>Telepon Orang Tua</strong>
            <?php echo Form::text('santri_parent_telephone', $santri->santri_parent_job, ["class" => "form-control"]); ?>

        </div>
      </div>
      <div class="ibox-content">
        <button type="submit" class="btn btn-primary">Save</button>
        <button type="reset" class="btn btn-danger btn-large">Reset</button>
      </div>
    </div>
    <?php echo Form::close(); ?>  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>