<!DOCTYPE html>
<html lang="ind">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pembayaran Spp</title>
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<div id="wrapper">
  <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div id="page-wrapper" class="gray-bg">
    <div class="row border-bottom">
      <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    <div class="footer">
      <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</div>
<?php echo $__env->make('includes.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>