<?php $__env->startSection('content'); ?>
<div>
  <div>
    <?php if(!empty($profile->pesantren_profile_logo) 
        && file_exists(App\PesantrenProfile::IMAGE_PATH.$profile->pesantren_profile_logo)): ?>
        <img src="<?php echo e(url(App\PesantrenProfile::IMAGE_PATH.$profile->pesantren_profile_logo)); ?>" width="200" height="200">
    <?php else: ?>
        <h1 class="logo-name"><?php echo e(CodeHelper::createAcronym($profile->pesantren_profile_name)); ?></h1>
    <?php endif; ?>
  </div>
  <h3><?php echo e($profile->pesantren_profile_name); ?></h3>
  <p><?php echo e($profile->pesantren_profile_address); ?></p>
    <?php echo e(Form::open(['route' => 'admin.loginPost'])); ?>

      <?php if(\Session::has('alert')): ?>
        <div class="alert alert-danger">
          <div><?php echo e(Session::get('alert')); ?></div>
        </div>
      <?php endif; ?>
      <div class="form-group">
        <?php echo Form::email('email', null, ["class" => "form-control", "required" => "required", "placeholder" => "Email"]); ?>

      </div>
      <div class="form-group">
        <?php echo Form::password('password', ["class" => "form-control", "required" => "required", "placeholder" => "Password"]); ?>

      </div>
      <button type="submit" class="btn btn-primary block full-width m-b">Login</button>
      <?php echo Form::close(); ?>  
    <p class="m-t"> <small>Copyright &copy; All Right Reserved 2018 <?php echo e(date('Y') == '2018' ? "" : "- ".date('Y').""); ?></small> </p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>