<div>       
	<strong>Copyright</strong> Pembayaran SPP &copy; <?php echo e(date('Y')); ?>      
</div>