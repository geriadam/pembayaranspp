<div>       
	<strong>Copyright</strong> Pembayaran SPP &copy; {{ date('Y') }}      
</div>